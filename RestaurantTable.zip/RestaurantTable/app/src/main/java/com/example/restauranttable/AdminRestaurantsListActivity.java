package com.example.restauranttable;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminRestaurantsListActivity extends AppCompatActivity {
    List<Cheque> productList;
    RecyclerView recyclerView;
    AdminRestaurantsAdapter adminRestaurantsAdapter;
    FloatingActionButton floatingActionButton;
    ProgressDialog loading;
    Button logout, myBookings, users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_restaurants_list);
        floatingActionButton = findViewById(R.id.fabAdd);
        recyclerView = findViewById(R.id.re);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        productList = new ArrayList<>();
        logout = findViewById(R.id.logout);
        myBookings = findViewById(R.id.my_bookings);
        users = findViewById(R.id.users);

        loading = new ProgressDialog(this);
        loading.setTitle("Loading");
        loading.setCancelable(false);


        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(AdminRestaurantsListActivity.this, AddRestaurants.class);
                startActivity(i);
            }
        });

        myBookings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(AdminRestaurantsListActivity.this, AdminBookingsActivity.class);
                startActivity(i);
            }
        });

        users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(AdminRestaurantsListActivity.this, UsersListActivity.class);
                startActivity(i);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedpreferences = getSharedPreferences("data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.clear();
                editor.apply();

                Intent i = new Intent(AdminRestaurantsListActivity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProducts();
        Log.d("Arn", "onResume");
    }

    private void loadProducts() {

        Log.d("Arn", "loadProducts");
        if (loading != null)
            loading.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "http://javatrainingkerala.com/restaurants/viewrestaurants.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        Log.d("Arn", "response = " + response);
                        // swipe.setRefreshing(false);
                        try {
                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);

                            Log.d("Arn", "array = " + array);

                            //traversing through all the object
                            productList.clear();
                            for (int i = array.length() - 1; i >= 0; i--) {


                                //getting product object from json array
                                JSONObject product = array.getJSONObject(i);

                                Log.d("Arn", "Product = " + product);
                                //adding the product to product list

                                productList.add(new Cheque(product.getString("id"),
                                        product.getString("name"),
                                        product.getString("address"),
                                        product.getString("phone"),
                                        product.getString("cuisine"),
                                        product.getString("menu"),
                                        product.getString("image"),
                                        product.getString("seat"),
                                        product.getString("password")


                                ));
                            }

                            recyclerView.setAdapter(null);

                            adminRestaurantsAdapter = new AdminRestaurantsAdapter(AdminRestaurantsListActivity.this, productList);
                            adminRestaurantsAdapter.notifyDataSetChanged();
                            recyclerView.setAdapter(adminRestaurantsAdapter);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        Log.d("Arn", "error = " + error);
                    }


                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request


                //returning parameter
                return params;
            }

        };

        //Adding the string request to the queue
        RequestQueue requestQueue = Volley.newRequestQueue(AdminRestaurantsListActivity.this);
        requestQueue.add(stringRequest);
    }

    public void deleteProducts(final String id, final int position) {

        Log.d("Arn", "deleteProducts");
        if (loading != null)
            loading.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/delete.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        Log.d("Arn", "response = " + response);
                        // swipe.setRefreshing(false);
                        if (response.equals("Deleted"))
                            adminRestaurantsAdapter.removeItem(position);

                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        Log.d("Arn", "error = " + error);
                    }


                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request
                params.put("id", id);
                Log.d("Arn", "params = " + params);
                //returning parameter
                return params;
            }

        };

        //Adding the string request to the queue
        RequestQueue requestQueue = Volley.newRequestQueue(AdminRestaurantsListActivity.this);
        requestQueue.add(stringRequest);
    }

}
