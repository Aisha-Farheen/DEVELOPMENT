package com.example.restauranttable;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    EditText username, password;
    Button submit, sign,btnRestaurantLogin;
    Intent intent;
    TextView textView;
    ProgressDialog loading;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.editText);
        password = findViewById(R.id.editText2);
        submit = findViewById(R.id.button);
        btnRestaurantLogin = findViewById(R.id.btnRestaurantLogin);
        sign = findViewById(R.id.button2);
        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.textView);
        loading = new ProgressDialog(this);
        loading.setTitle("Login...");
        loading.setCancelable(false);

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forgot = new Intent(LoginActivity.this, forgot.class);
                startActivity(forgot);
            }
        });
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, RegisterUser.class);
                startActivity(i);
            }
        });

        btnRestaurantLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, RestaurantLoginActivity.class);
                startActivity(i);
                finish();
            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, Adminlogin.class));
                finish();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailPattern = "[a-zA-Z-0-9._]+@[a-z]+\\.+[a-z]+";
                username.setError(null);
                password.setError(null);

                if (username.getText().toString().isEmpty()) {
                    username.setError("Empty Field");
                } else if (password.getText().toString().isEmpty()) {
                    password.setError("Empty Field");
                } else if (!username.getText().toString().matches(emailPattern)) {
                    username.setError("Email not valid");
                } else {
                    if (loading != null)
                        loading.show();
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/login.php",
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {

                                    if (loading != null && loading.isShowing())
                                        loading.dismiss();

                                    try {
                                        JSONObject jsonObject = new JSONObject(response);
                                        Toast.makeText(LoginActivity.this, response, Toast.LENGTH_LONG).show();

                                        if (jsonObject.get("status").equals("success")) {

                                            String id = jsonObject.get("id").toString();

                                            SharedPreferences sharedpreferences = getSharedPreferences("data", MODE_PRIVATE);
                                            SharedPreferences.Editor editor = sharedpreferences.edit();
                                            editor.putString("id", id);
                                            editor.apply();

                                            Intent i = new Intent(LoginActivity.this, RestaurantsList.class);
                                            startActivity(i);
                                            finish();
                                        } else {
                                            Toast.makeText(LoginActivity.this, "Login  - " + jsonObject.get("status").toString(), Toast.LENGTH_LONG).show();
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }


                                }

                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    if (loading != null && loading.isShowing())
                                        loading.dismiss();
                                    Toast.makeText(LoginActivity.this, "Login Failed - " + error, Toast.LENGTH_LONG).show();
                                }
                            }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> params = new HashMap<>();
                            params.put("username", username.getText().toString());
                            params.put("password", password.getText().toString());
                            return params;
                        }
                    };

                    RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
                    requestQueue.add(stringRequest);
                }


            }
        });
    }
}


