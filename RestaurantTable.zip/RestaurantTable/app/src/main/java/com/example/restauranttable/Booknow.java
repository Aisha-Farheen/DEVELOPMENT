package com.example.restauranttable;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Booknow extends AppCompatActivity implements View.OnClickListener, PaymentResultListener {
    Intent i;
    ImageView img;
    TextView txt11, num;
    EditText date, time, seats;
    int minute;
    int h, m;
    Button btn11;
    Cheque cheque;
    float amount;
    private int mYear, mMonth, mDay, mHour, mMinute, mSec;
    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booknow);
        date = findViewById(R.id.editText21);
        time = findViewById(R.id.editText22);
        date.setOnClickListener(this);
        btn11 = findViewById(R.id.button11);
        seats = findViewById(R.id.editText23);
        time.setOnClickListener(this);
        i = getIntent();
        img = findViewById(R.id.imageView6);
        txt11 = findViewById(R.id.textView11);
        loading = new ProgressDialog(this);
        loading.setTitle("Loading...");
        loading.setCancelable(false);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            cheque = (Cheque) bundle.getSerializable("restaurant");
            if (cheque != null) {
                setEditData();
            }
        }

        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAlreadyExist();
            }
        });
    }

    private void checkAlreadyExist() {


        if ("".equals(date.getText().toString())) {
            Toast.makeText(Booknow.this, "Fields Empty", Toast.LENGTH_LONG).show();
        } else if ("".equals(time.getText().toString())) {
            Toast.makeText(Booknow.this, "Fields Empty", Toast.LENGTH_LONG).show();
        } else if ("".equals(seats.getText().toString())) {
            Toast.makeText(Booknow.this, "Fields Empty", Toast.LENGTH_LONG).show();
        } else {

            if (loading != null)
                loading.show();
            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/booking_check.php",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            if (loading != null && loading.isShowing())
                                loading.dismiss();

                            try {

                                Log.d("Arun","response :"+response);
                               // Toast.makeText(Booknow.this, response, Toast.LENGTH_LONG).show();

                                if (response.equals("exist")) {
                                    Toast.makeText(Booknow.this, "Booking Already Exist", Toast.LENGTH_LONG).show();
                                } else if(response.equals("full")){
                                    Toast.makeText(Booknow.this, "Seats not available now", Toast.LENGTH_LONG).show();
                                }else {
                                    startPayment();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                        }

                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            if (loading != null && loading.isShowing())
                                loading.dismiss();
                            Toast.makeText(Booknow.this, "Request Failed - " + error, Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();

                    SharedPreferences sharedpreferences = getSharedPreferences("data", MODE_PRIVATE);
                    String id = sharedpreferences.getString("id", "");

                    params.put("user_id", id);
                    params.put("restaurent_id", cheque.getId());
                    params.put("date", date.getText().toString());
                    params.put("time", time.getText().toString());
                    params.put("seat", seats.getText().toString());

                    Log.d("Arun","params :"+params);
                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(Booknow.this);
            requestQueue.add(stringRequest);
        }
    }

    private void setEditData() {
        txt11.setText(cheque.getImage());
        Picasso.get().load(cheque.getUser4()).into(img);
    }

    @Override
    public void onClick(View v) {

        if (v == date) {
            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            Calendar newDate = Calendar.getInstance();
                            newDate.set(year, monthOfYear, dayOfMonth);
                            date.setText(getDateStringFromMilliSeconds(newDate.getTimeInMillis()));

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
            datePickerDialog.show();
        }
        if (v == time) {
            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);
            mSec = c.get(Calendar.SECOND);
            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            time.setText(hourOfDay + ":" + minute);
                            h = hourOfDay;
                            m = minute;
                        }
                    }, mHour, mMinute, true);
            timePickerDialog.show();
        }


    }

    public static String getDateStringFromMilliSeconds(Long s) {
        try {
            DateFormat simple = new SimpleDateFormat("dd-MM-yyyy");
            Date result = new Date(s);
            return simple.format(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public void startPayment() {
        /*
          You need to pass current activity in order to let Razorpay create CheckoutActivity
         */
        final Activity activity = this;

        final Checkout co = new Checkout();

        try {
            JSONObject options = new JSONObject();
            options.put("name", "Razorpay Corp");
            options.put("description", "Demoing Charges");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png");
            options.put("currency", "INR");

            amount = (Integer.parseInt(seats.getText().toString()) * 50*100);
            options.put("amount", amount);

            JSONObject preFill = new JSONObject();
            preFill.put("email", "test@razorpay.com");
            preFill.put("contact", "9876543210");

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }

    @Override
    public void onPaymentSuccess(String s) {
        Toast.makeText(Booknow.this, "Payment success", Toast.LENGTH_SHORT)
                .show();

        SharedPreferences sharedpreferences = getSharedPreferences("data", MODE_PRIVATE);
        String id = sharedpreferences.getString("id", "");

        Log.d("id - ", id);

        if (!"".equals(id)) {
            startActivity(new Intent(Booknow.this, receipt.class).putExtra("id", id).putExtra("tid", s).putExtra("amount", amount + "").putExtra("date", date.getText().toString()).putExtra("seat", seats.getText().toString()).putExtra("restaurant", cheque).putExtra("time", time.getText().toString()));
        }
    }

    @Override
    public void onPaymentError(int i, String s) {
        Toast.makeText(Booknow.this, "Payment failed", Toast.LENGTH_SHORT)
                .show();
    }
}

