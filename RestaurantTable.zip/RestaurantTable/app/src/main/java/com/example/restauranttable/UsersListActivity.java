package com.example.restauranttable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsersListActivity extends AppCompatActivity {


    List<User> userList=new ArrayList<>();
    RecyclerView recyclerView;
    ProgressDialog loading;
    UserAdapter userAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_list);

        recyclerView = findViewById(R.id.reUsers);
        recyclerView.setHasFixedSize(true);
        userAdapter = new UserAdapter(this);
        recyclerView.setAdapter(userAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loading = new ProgressDialog(this);
        loading.setTitle("Loading");
        loading.setCancelable(false);

        loadUsers();
    }

    private void loadUsers() {

        Log.d("Arn", "loadUsers");
        if (loading != null)
            loading.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "http://javatrainingkerala.com/restaurants/userlist.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        Log.d("Arn", "response = " + response);
                        userList.clear();

                        JSONObject jsonObject = null;
                        try {
                            jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("data");
                            Log.d("Arn", "array = " + jsonArray);
                            userList = new Gson().fromJson(String.valueOf(jsonArray), new TypeToken<List<User>>() {
                            }.getType());

                            userAdapter.setList(userList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        Log.d("Arn", "error = " + error);
                    }


                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                return params;
            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                20000,0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        //Adding the string request to the queue
        RequestQueue requestQueue = Volley.newRequestQueue(UsersListActivity.this);
        requestQueue.add(stringRequest);
    }

}
