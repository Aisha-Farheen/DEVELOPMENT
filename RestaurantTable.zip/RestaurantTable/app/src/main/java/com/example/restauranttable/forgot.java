package com.example.restauranttable;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class forgot extends AppCompatActivity {
    EditText editText13;
    Button button5;
    ProgressDialog loading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);
        editText13=findViewById(R.id.editText13);
        button5=findViewById(R.id.button5);

        loading = new ProgressDialog(this);
        loading.setTitle("Loading...");
        loading.setCancelable(false);

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editText13.getText().toString().isEmpty())
                {
                    editText13.setError("Empty field");
                }
                else
                {
                    if (loading != null)
                        loading.show();

                    StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/forgot_password.php",
                            new Response.Listener<String>()
                            {

                                @Override
                                public void onResponse(String response)
                                {
//If we are getting success from server

                                    if (loading != null && loading.isShowing())
                                        loading.dismiss();

                                    Toast.makeText(forgot.this,"Password set to your email."+ response, Toast.LENGTH_LONG).show();
                                    finish();
                                }

                            },
                            new Response.ErrorListener()
                            {

                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
//You can handle error here if you want
                                    if (loading != null && loading.isShowing())
                                        loading.dismiss();
                                    Log.d("Arn","Error = "+error);
                                }
                            }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError
                        {
                            Map<String, String> params = new HashMap<>();
//Adding parameters to reques
                            params.put("email", editText13.getText().toString());
                            //params.put("password",forgot.getStringExtra(password:"password"));
                            // params.put("cpassword",cpassword.getText().toString());

// Toast.makeText(LoginActivity.this,"submitted",Toast.LENGTH_LONG).show();

//returning parameter
                            return params;
                        }
                    };
// m = Integer.parseInt(ba) - Integer.parseInt(result.getContents());
// balance.setText(m+"");
//Adding the string request to the queue
                    stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                            20000, 0,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                    RequestQueue requestQueue = Volley.newRequestQueue(forgot.this);
                    requestQueue.add(stringRequest);
                }


            }

        });
    }
}

