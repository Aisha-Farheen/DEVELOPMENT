package com.example.restauranttable;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import static android.content.Context.MODE_PRIVATE;

public class BookingsAdapter extends RecyclerView.Adapter<BookingsAdapter.ProductViewHolder> {
    Intent i;
    SharedPreferences sh;
    boolean isFromAdmin;
    private Context mCtx;
    private List<Booking> productList;

    public BookingsAdapter(boolean isFromAdmin, Context mCtx, List<Booking> productList) {
        sh = Objects.requireNonNull(mCtx).getSharedPreferences("data", MODE_PRIVATE);
        this.mCtx = mCtx;
        this.productList = productList;
        this.isFromAdmin = isFromAdmin;
        // sh=mCtx.getSharedPreferences("Official1",MODE_PRIVATE);
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.item_booking, parent, false);
        view.setLayoutParams(new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        return new ProductViewHolder(view);

    }

    @Override
    public void onBindViewHolder(final ProductViewHolder holder, final int position) {
        final Booking cheque = productList.get(position);

        holder.name.setText(cheque.getRestaurantName());
        if (isFromAdmin) {
            holder.uname.setText("Booked by : " + cheque.getUsername());
            holder.uname.setVisibility(View.VISIBLE);
        } else {
            holder.uname.setVisibility(View.GONE);
        }
        holder.amount.setText("Amount : "+cheque.getAmount());

        Log.d("Arn", "date =" + cheque.getDate());
        if (cheque.getDate() != null)
            holder.date.setText("Date : " + getDateStringFromMilliSeconds(Long.parseLong(cheque.getDate())));
        holder.time.setText(cheque.getTime());
        holder.seat.setText("Seats : "+cheque.getSeat());

        if (isFromAdmin) {
            holder.cancel.setVisibility(View.GONE);
        } else {
            holder.cancel.setVisibility(View.VISIBLE);
            holder.cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ((UserBookingsActivity) mCtx).cancelBooking(cheque.getId(), position);
                }
            });
        }

    }

    public static String getDateStringFromMilliSeconds(Long s) {
        try {
            Calendar cal = Calendar.getInstance(Locale.ENGLISH);
            cal.setTimeInMillis(s*1000L);
            String date = DateFormat.format("dd-MM-yyyy", cal).toString();
            return date;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public void removeItem(int position) {
        productList.remove(position);
        notifyItemRemoved(position);
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {


        TextView name, uname, amount, date, time, seat;
        Button cancel;


        public ProductViewHolder(View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.r_name);
            uname = itemView.findViewById(R.id.u_name);
            amount = itemView.findViewById(R.id.amount);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            seat = itemView.findViewById(R.id.seat);
            cancel = itemView.findViewById(R.id.cancel);
        }


    }

}
