package com.example.restauranttable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RestaurantHomeActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    ProgressDialog loading;

    List<Booking> bookings = new ArrayList<>();
    BookingsAdapter bookingsAdapter;

    Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_home);

        recyclerView = findViewById(R.id.re);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        logout = findViewById(R.id.logout);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedpreferences = getSharedPreferences("data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.clear();
                editor.apply();

                Intent i = new Intent(RestaurantHomeActivity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        });

        loadBookings();
    }

    private void loadBookings() {
        if (loading != null)
            loading.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/get_restaurant.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        try {

                            //converting the string to json array object

                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray array =jsonObject.getJSONArray("data");
                            bookings.clear();
                            //traversing through all the object
                            for (int i = array.length() - 1; i >= 0; i--) {

                                JSONObject product = array.getJSONObject(i);
                                //adding the product to product list
                                bookings.add(new Booking(product.getString("id"),
                                        product.getString("user_id"),
                                        product.getString("name"),
                                        product.getString("restaurants_id"),
                                        product.getString("restaurant_name"),
                                        product.getString("date"),
                                        product.getString("time"),
                                        product.getString("amount"),
                                        product.getString("seat")

                                ));
                            }

                            bookingsAdapter = new BookingsAdapter(true, RestaurantHomeActivity.this, bookings);
                            bookingsAdapter.notifyDataSetChanged();
                            recyclerView.setAdapter(bookingsAdapter);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                    }


                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request

                SharedPreferences sharedpreferences = getSharedPreferences("data", MODE_PRIVATE);
                String id = sharedpreferences.getString("rid", "");
                Log.d("rid - ", id);

                params.put("rid", id);

                //returning parameter
                return params;
            }

        };

        //Adding the string request to the queue
        RequestQueue requestQueue = Volley.newRequestQueue(RestaurantHomeActivity.this);
        requestQueue.add(stringRequest);
    }
    public void cancelBooking(final String id, final int position) {
        Log.d("Arn", "cancelBooking");
        if (loading != null)
            loading.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/deletebooking.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        Log.d("Arn", "response = " + response);
                        // swipe.setRefreshing(false);
                        if (response.equals("Deleted"))
                            bookingsAdapter.removeItem(position);
                        else
                            Toast.makeText(RestaurantHomeActivity.this, response, Toast.LENGTH_LONG).show();

                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        Log.d("Arn", "error = " + error);
                    }


                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request
                params.put("id", id);
                Log.d("Arn", "params = " + params);
                //returning parameter
                return params;
            }

        };

        //Adding the string request to the queue
        RequestQueue requestQueue = Volley.newRequestQueue(RestaurantHomeActivity.this);
        requestQueue.add(stringRequest);
    }

}
