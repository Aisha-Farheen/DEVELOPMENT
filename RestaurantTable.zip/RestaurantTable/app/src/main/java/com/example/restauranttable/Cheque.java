package com.example.restauranttable;

import java.io.Serializable;

public class Cheque implements Serializable {



    private String id;
    private String image;
    private String status;

    private String user1;
    private String user2;

    private String user3;
    private String user4;

    String seat;
    String password;


    public Cheque(String id,String image, String status, String user1, String user2, String user3, String user4,String seat,String password) {

        this.id=id;
        this.image = image;
        this.status = status;

        this.user1=user1;
        this.user2=user2;

        this.user3=user3;
        this.user4=user4;
        this.seat=seat;
        this.password=password;

    }

    public Cheque() {
    }


    public String getImage() {
        return image;
    }
    public String getStatus() {
        return status;
    }

    public String getUser1() {
        return user1;
    }
    public String getUser2() {
        return user2;
    }
    public String getUser3() {
        return user3;
    }
    public String getUser4() {
        return user4;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setUser1(String user1) {
        this.user1 = user1;
    }

    public void setUser2(String user2) {
        this.user2 = user2;
    }

    public void setUser3(String user3) {
        this.user3 = user3;
    }

    public void setUser4(String user4) {
        this.user4 = user4;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}




//   public String getPrize() { return  prize; }}
