package com.example.restauranttable;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class AddRestaurants extends AppCompatActivity {
    EditText name, address, phone, cuisine, menu, seats, password;
    Intent intent;
    Button image, submit;
    ImageView img;
    Uri filePath;
    Bitmap bitmap;

    Cheque cheque;
    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restdetails);
        name = findViewById(R.id.editText14);
        address = findViewById(R.id.editText15);
        phone = findViewById(R.id.editText16);
        cuisine = findViewById(R.id.editText17);
        menu = findViewById(R.id.editText18);
        seats = findViewById(R.id.etSeats);
        password = findViewById(R.id.etPassword);

        submit = findViewById(R.id.button7);
        image = findViewById(R.id.button8);
        img = findViewById(R.id.imageView4);
        loading = new ProgressDialog(this);
        loading.setTitle("Uploading");
        loading.setCancelable(false);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            cheque = (Cheque) bundle.getSerializable("restaurant");
            if (cheque != null) {
                setEditData();
            }
        }

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);

            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                submitBase64();
                // submitMultipart();
            }
        });
    }

/*
    private void submitMultipart() {
        if (name.getText().toString().isEmpty() || address.getText().toString().isEmpty()
                || phone.getText().toString().isEmpty() || cuisine.getText().toString().isEmpty()
                || menu.getText().toString().isEmpty() || seats.getText().toString().isEmpty() || password.getText().toString().isEmpty()) {
            Toast.makeText(AddRestaurants.this, "Empty Fields", Toast.LENGTH_LONG).show();
        } else if (phone.getText().toString().length() <= 9 || phone.getText().toString().length() > 13) {
            phone.setError("Enter valid phone");
        } else {
            if (loading != null)
                loading.show();
            VolleyMultipartRequest multipartRequest = new VolleyMultipartRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/insertrestaurants.php", new Response.Listener<NetworkResponse>() {
                @Override
                public void onResponse(NetworkResponse response) {
                    String resultResponse = new String(response.data);
                    Toast.makeText(AddRestaurants.this, resultResponse, Toast.LENGTH_LONG).show();
                    Log.d("Arn", "response = " + response);
                    if (resultResponse.equals("success")) {
                        finish();
                    }

                    if (loading != null && loading.isShowing()) {
                        loading.dismiss();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    error.printStackTrace();
                    if (loading != null && loading.isShowing()) {
                        loading.dismiss();
                    }

                }
            }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();

                    params.put("name", name.getText().toString());
                    params.put("address", address.getText().toString());
                    params.put("phone", phone.getText().toString());
                    params.put("cuisine", cuisine.getText().toString());
                    params.put("menu", menu.getText().toString());
                    params.put("seat", seats.getText().toString());
                    params.put("password", password.getText().toString());

                    Log.d("Arn", "params = " + params);
                    return params;
                }

                @Override
                protected Map<String, DataPart> getByteData() {
                    Map<String, DataPart> params = new HashMap<>();
                    params.put("img", new DataPart("file_avatar.jpg", getFileDataFromDrawable(bitmap)));

                    Log.d("Arn", "params = " + params);
                    return params;
                }
            };

            multipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                    50000,0,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            VolleySingleton.getInstance(getBaseContext()).addToRequestQueue(multipartRequest);

        }
    }
*/

/*    public byte[] getFileDataFromDrawable(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }*/

    private void submitBase64() {
        if (name.getText().toString().isEmpty() || address.getText().toString().isEmpty()
                || phone.getText().toString().isEmpty() || cuisine.getText().toString().isEmpty()
                || menu.getText().toString().isEmpty() || seats.getText().toString().isEmpty() || password.getText().toString().isEmpty()) {
            Toast.makeText(AddRestaurants.this, "Empty Fields", Toast.LENGTH_LONG).show();
        } else if (phone.getText().toString().length() <= 9 || phone.getText().toString().length() > 13) {
            phone.setError("Enter valid phone");
        } else {
            class UploadImage extends AsyncTask<Void, Void, String> {


                RequestHandler rh = new RequestHandler();

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    if (loading != null)
                        loading.show();
                }


                @Override
                protected void onPostExecute(String s) {
                    super.onPostExecute(s);

                    Toast.makeText(AddRestaurants.this, s, Toast.LENGTH_LONG).show();

                    if (s.equals("success")) {
                        finish();
                    }

                    if (loading != null && loading.isShowing()) {
                        loading.dismiss();
                    }

                }

                @SuppressLint("WrongThread")
                @Override
                protected String doInBackground(Void... voids) {

                    String uploadImage = getStringImage(bitmap);


                    HashMap<String, String> data = new HashMap<>();

                    data.put("name", name.getText().toString());
                    data.put("address", address.getText().toString());
                    data.put("phone", phone.getText().toString());
                    data.put("cuisine", cuisine.getText().toString());
                    data.put("menu", menu.getText().toString());
                    data.put("seat", seats.getText().toString());
                    data.put("password", password.getText().toString());
                    data.put("img", uploadImage);

                    String result;

                    Log.d("Arn", "data = " + data);

                    if (cheque != null) {
                        data.put("id", cheque.getId() + "");

                        result = rh.sendPostRequest("http://javatrainingkerala.com/restaurants/update.php", data);
                    } else {

                        result = rh.sendPostRequest("http://javatrainingkerala.com/restaurants/insertrestaurants.php", data);
                    }

                    Log.d("Arn", "data = " + data);
                    Log.d("Arn", "result = " + result);
                    return result;
                }
            }
            UploadImage ui = new UploadImage();
            ui.execute();

        }
    }


    private void setEditData() {

        name.setText(cheque.getImage());
        address.setText(cheque.getStatus());
        Picasso.get().load(cheque.getUser4()).into(img);


        BitmapDrawable drawable = (BitmapDrawable) img.getDrawable();
        if (drawable != null)
            bitmap = drawable.getBitmap();

        phone.setText(cheque.getUser1());
        cuisine.setText(cheque.getUser2());
        menu.setText(cheque.getUser3());
        seats.setText(cheque.getSeat());
        password.setText(cheque.getPassword());

    }

    public String getStringImage(Bitmap bmp) {
        if (bmp != null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] imageBytes = baos.toByteArray();
            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
            return encodedImage;
        } else
            return null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                img.setImageBitmap(bitmap);
                getStringImage(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String getPath(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader loader = new CursorLoader(getApplicationContext(), contentUri, proj, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String result = cursor.getString(column_index);
        cursor.close();
        return result;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}





