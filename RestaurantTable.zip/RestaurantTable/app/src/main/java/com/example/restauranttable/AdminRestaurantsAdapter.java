package com.example.restauranttable;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static android.content.Context.MODE_PRIVATE;

public class AdminRestaurantsAdapter extends RecyclerView.Adapter<AdminRestaurantsAdapter.ProductViewHolder> {
    Intent i;
    SharedPreferences sh;

    private Context mCtx;
    private List<Cheque> productList;

    public AdminRestaurantsAdapter(Context mCtx, List<Cheque> productList) {
        sh = Objects.requireNonNull(mCtx).getSharedPreferences("data", MODE_PRIVATE);
        this.mCtx = mCtx;
        this.productList = productList;
        // sh=mCtx.getSharedPreferences("Official1",MODE_PRIVATE);
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.item_admin_restaurant, parent, false);
        view.setLayoutParams(new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        return new ProductViewHolder(view);

    }

    @Override
    public void onBindViewHolder(final ProductViewHolder holder, final int position) {
        final Cheque cheque = productList.get(position);

        holder.name.setText(cheque.getImage());
        holder.detalis.setText("Address :"+cheque.getStatus());


        Picasso.get().load(cheque.getUser4()).networkPolicy(NetworkPolicy.NO_CACHE)
                .memoryPolicy(MemoryPolicy.NO_CACHE).placeholder(mCtx.getResources().getDrawable(R.drawable.aaaa)).into(holder.image);
        holder.ph.setText("Cuisine :"+cheque.getUser2());
        holder.call.setText("Menu :"+cheque.getUser3());
        holder.view.setText("Phone :"+cheque.getUser1());
        holder.txtSeat.setText("Seats : "+cheque.getSeat());
        sh = Objects.requireNonNull(mCtx).getSharedPreferences("data", MODE_PRIVATE);

        holder.btn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCtx.startActivity(new Intent(mCtx, AddRestaurants.class).putExtra("restaurant", cheque));
            }
        });

        holder.btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((AdminRestaurantsListActivity) mCtx).deleteProducts(cheque.getId(), position);
            }
        });
    }


    @Override
    public int getItemCount() {
        return productList.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {


        TextView name, view, detalis, a, ph, app, call, msg, lo, la, map, share,txtSeat;
        ImageView image;
        Button btn_edit, btn_delete;


        public ProductViewHolder(View itemView) {
            super(itemView);

            txtSeat= itemView.findViewById(R.id.txtSeat);
            name = itemView.findViewById(R.id.textView4);
            ph = itemView.findViewById(R.id.textView6);
            detalis = itemView.findViewById(R.id.textView7);
            image = itemView.findViewById(R.id.imageView2);
            btn_delete = itemView.findViewById(R.id.btn_delete);
            call = itemView.findViewById(R.id.textView9);
            view = itemView.findViewById(R.id.textView10);
            btn_edit = itemView.findViewById(R.id.btn_edit);
        }

    }

    public void filterList(ArrayList<Cheque> filteredList) {
        productList = filteredList;
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        productList.remove(position);
        notifyItemRemoved(position);
    }
}
