package com.example.restauranttable;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class receipt extends AppCompatActivity {
    TextView txt14, txt12;
    Intent i;
    int i1;

    ProgressDialog loading;
    Cheque cheque;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);
        txt14 = findViewById(R.id.textView14);
        txt12 = findViewById(R.id.textView12);

        loading = new ProgressDialog(this);
        loading.setTitle("Loading...");
        loading.setCancelable(false);

        i = getIntent();
        Random r = new Random();
        i1 = r.nextInt(450 - 280) + 28;
        txt14.setText(String.valueOf(i1));

        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
            cheque = (Cheque) bundle.getSerializable("restaurant");


        final String id = i.getStringExtra("id");
        final String restaurant_name = cheque.getImage();
        final String restaurant_id = cheque.getId();
        final String date = i.getStringExtra("date");
        final String seat = i.getStringExtra("seat");
        final String time = i.getStringExtra("time");
        final String amount = i.getStringExtra("amount");
        final String payment_status = "success";


        if (cheque != null) {

            Log.d("Arn", "cheque - " + cheque);

            if (loading != null)
                loading.show();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/bookinginsert.php",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            if (loading != null && loading.isShowing())
                                loading.dismiss();

                            try {

                                Toast.makeText(receipt.this, response, Toast.LENGTH_LONG).show();

                                if (response.equals("Booked")) {
                                    Intent i = new Intent(receipt.this, RestaurantsList.class);
                                    startActivity(i);
                                    finish();
                                } else {
                                    Toast.makeText(receipt.this, response, Toast.LENGTH_LONG).show();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                        }

                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            if (loading != null && loading.isShowing())
                                loading.dismiss();
                            Toast.makeText(receipt.this, "Failed - " + error, Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();

                    params.put("id", id);
                    params.put("restaurant_name", restaurant_name);
                    params.put("restaurant_id", restaurant_id);
                    params.put("date", date);
                    params.put("time", time);
                    params.put("seat", seat);
                    params.put("amount", amount);
                    params.put("payment_status", payment_status);

                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(receipt.this);
            requestQueue.add(stringRequest);
        }
    }
}



