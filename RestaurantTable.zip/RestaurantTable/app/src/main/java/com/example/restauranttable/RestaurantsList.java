package com.example.restauranttable;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RestaurantsList extends AppCompatActivity {
    List<Cheque> productList;
    RecyclerView recyclerView;
    Chequeadapter adapter;

    ProgressDialog loading;

    Button logout, myBookings;

    EditText search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_restaurants_list);
        recyclerView = findViewById(R.id.re);
        search = findViewById(R.id.editText24);

        logout = findViewById(R.id.logout);
        myBookings = findViewById(R.id.my_bookings);


        loading = new ProgressDialog(this);
        loading.setTitle("Loading...");
        loading.setCancelable(false);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        productList = new ArrayList<>();
        loadProducts();
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                filter(editable.toString());
            }
        });


        myBookings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(RestaurantsList.this, UserBookingsActivity.class);
                startActivity(i);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedpreferences = getSharedPreferences("data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.clear();
                editor.apply();

                Intent i = new Intent(RestaurantsList.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        });

    }

    private void loadProducts() {
        if (loading != null)
            loading.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/viewrestaurants.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        try {
                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);
                            productList.clear();
                            //traversing through all the object
                            for (int i = array.length() - 1; i >= 0; i--) {

                                JSONObject product = array.getJSONObject(i);
                                //adding the product to product list
                                productList.add(new Cheque(product.getString("id"),
                                        product.getString("name"),
                                        product.getString("address"),
                                        product.getString("phone"),
                                        product.getString("cuisine"),
                                        product.getString("menu"),
                                        product.getString("image"),
                                        product.getString("seat"),
                                        product.getString("password")

                                ));
                            }

                            adapter = new Chequeadapter(RestaurantsList.this, productList);
                            adapter.notifyDataSetChanged();
                            recyclerView.setAdapter(adapter);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                    }


                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request


                //returning parameter
                return params;
            }

        };

        //Adding the string request to the queue
        RequestQueue requestQueue = Volley.newRequestQueue(RestaurantsList.this);
        requestQueue.add(stringRequest);
    }

    private void filter(String text) {
        ArrayList<Cheque> filteredList = new ArrayList<>();

        for (Cheque item : productList) {
            if (item.getUser2().toLowerCase().contains(text.toLowerCase()) || item.getUser1().toLowerCase().contains(text.toLowerCase()) || item.getUser3().contains(text.toLowerCase()) || item.getStatus().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }

        if (adapter != null)
            adapter.filterList(filteredList);
    }
}
