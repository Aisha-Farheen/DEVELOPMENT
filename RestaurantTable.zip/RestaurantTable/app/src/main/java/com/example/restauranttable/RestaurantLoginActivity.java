package com.example.restauranttable;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RestaurantLoginActivity extends AppCompatActivity {

    EditText username, password;
    Button btnLogin;
    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_login);

        btnLogin = findViewById(R.id.btnLogin);

        password = findViewById(R.id.etPassword);
        username = findViewById(R.id.etUsername);

        loading = new ProgressDialog(this);
        loading.setTitle("Login...");
        loading.setCancelable(false);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });

    }

    private void login() {
        password.setError(null);
        username.setError(null);

        if (username.getText().toString().isEmpty()) {
            username.setError("Empty Field");
        } else if (password.getText().toString().isEmpty()) {
            password.setError("Empty Field");
        } else {
            if (loading != null) {
                loading.setTitle("Login...");
                loading.show();
            }
            StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/restaurant_login.php",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            if (loading != null && loading.isShowing())
                                loading.dismiss();
                            Log.d("Arn", "response = " + response);
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                Toast.makeText(RestaurantLoginActivity.this, response, Toast.LENGTH_LONG).show();

                                if (jsonObject.get("status").equals("success")) {

                                    String id = jsonObject.get("id").toString();

                                    SharedPreferences sharedpreferences = getSharedPreferences("data", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sharedpreferences.edit();
                                    editor.putString("rid", id);
                                    editor.apply();

                                    Intent i = new Intent(RestaurantLoginActivity.this, RestaurantHomeActivity.class);
                                    startActivity(i);
                                    finish();
                                } else {
                                    Toast.makeText(RestaurantLoginActivity.this, "Login  - " + jsonObject.get("status").toString(), Toast.LENGTH_LONG).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }

                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            if (loading != null && loading.isShowing())
                                loading.dismiss();
                            Toast.makeText(RestaurantLoginActivity.this, "Login Failed - " + error, Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("phone", username.getText().toString());
                    params.put("password", password.getText().toString());

                    Log.d("Arn", "params = " + params);

                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(RestaurantLoginActivity.this);
            requestQueue.add(stringRequest);
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(RestaurantLoginActivity.this, LoginActivity.class);
        startActivity(i);
        finish();
    }
}
