package com.example.restauranttable;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class RegisterUser extends AppCompatActivity {
    EditText name, phone, city, email, password;
    Button submit;

    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        name = findViewById(R.id.editText9);
        phone = findViewById(R.id.editText5);
        city = findViewById(R.id.editText10);
        email = findViewById(R.id.editText11);
        password = findViewById(R.id.editText8);
        submit = findViewById(R.id.button3);

        loading = new ProgressDialog(this);
        loading.setTitle("Register...");
        loading.setCancelable(false);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                String emailPattern = "[a-zA-Z-0-9._]+@[a-z]+\\.+[a-z]+";
                if (name.getText().toString().isEmpty() || phone.getText().toString().isEmpty() || city.getText().toString().isEmpty() || email.getText().toString().isEmpty() || password.getText().toString().isEmpty()) {
                    Toast.makeText(RegisterUser.this, "Empty field", Toast.LENGTH_LONG).show();
                } else if (phone.getText().toString().length() < 10) {
                    phone.setError("Please Match Requested Format");
                } else if (!email.getText().toString().matches(emailPattern)) {
                    Toast.makeText(RegisterUser.this, "Email not valid", Toast.LENGTH_LONG).show();
                } else {
                    if (loading != null)
                        loading.show();

                    StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://javatrainingkerala.com/restaurants/userregistration.php",
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
//If we are getting success from server
                                    if (loading != null && loading.isShowing())
                                        loading.dismiss();
                                    Toast.makeText(RegisterUser.this, response, Toast.LENGTH_LONG).show();
                                    if (response.equals("success")) {
                                        Intent i = new Intent(RegisterUser.this, LoginActivity.class);
                                        startActivity(i);
                                    } else {
                                        Toast.makeText(RegisterUser.this, "Registration Failure- " + response, Toast.LENGTH_LONG).show();

                                    }
                                }

                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
//You can handle error here if you want
                                    if (loading != null && loading.isShowing())
                                        loading.dismiss();
                                    Toast.makeText(RegisterUser.this, "Registration Failure - "+error, Toast.LENGTH_LONG).show();
                                }
                            }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> params = new HashMap<>();
//Adding parameters to request
                            params.put("name", name.getText().toString());
                            params.put("phone", phone.getText().toString());
                            params.put("city", city.getText().toString());
                            params.put("email", email.getText().toString());
                            params.put("password", password.getText().toString());

// Toast.makeText(LoginActivity.this,"submitted",Toast.LENGTH_LONG).show();

//returning parameter
                            return params;
                        }
                    };

                    RequestQueue requestQueue = Volley.newRequestQueue(RegisterUser.this);
                    requestQueue.add(stringRequest);
                }
            }


        });
    }
}
