package com.example.restauranttable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.whiteelephant.monthpicker.MonthPickerDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminBookingsActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    ProgressDialog loading;

    List<Booking> bookings = new ArrayList<>();
    BookingsAdapter bookingsAdapter;

    Button btnFilter, btnFull, btnMonthFilter;

    EditText etFilter, etMonthFilter;
    private int mYear, mMonth, mDay, mHour, mMinute, mSec;

    int month = 0;
    int year = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_bookings);

        recyclerView = findViewById(R.id.re);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        etFilter = findViewById(R.id.etFilter);
        etMonthFilter = findViewById(R.id.etMonthFilter);
        btnFilter = findViewById(R.id.btnFilter);
        btnFull = findViewById(R.id.btnFull);
        btnMonthFilter = findViewById(R.id.btnMonthFilter);

        loading = new ProgressDialog(this);
        loading.setTitle("L" +
                "oading");
        loading.setCancelable(false);

        loadBookings("");

        btnFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etMonthFilter.setText("");
                month = 0;
                year = 0;
                loadBookings(etFilter.getText().toString());
            }
        });
        btnFull.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etFilter.setText("");
                etMonthFilter.setText("");
                month = 0;
                year = 0;
                loadBookings("");
            }
        });

        etFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(AdminBookingsActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                Calendar newDate = Calendar.getInstance();
                                newDate.set(year, monthOfYear, dayOfMonth);
                                etFilter.setText(getDateStringFromMilliSeconds(newDate.getTimeInMillis()));

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        etMonthFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                monthPicker();
            }
        });

        btnMonthFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etFilter.setText("");
                loadBookings("");
            }
        });

    }

    public void monthPicker() {
        final Calendar today = Calendar.getInstance();
        MonthPickerDialog.Builder builder = new MonthPickerDialog.Builder(AdminBookingsActivity.this, new MonthPickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(int selectedMonth, int selectedYear) {
                Log.d("Arn", "selectedMonth : " + selectedMonth + 1 + " selectedYear : " + selectedYear);
                // Toast.makeText(AdminBookingsActivity.this, "Date set with month" + selectedMonth + " year " + selectedYear, Toast.LENGTH_SHORT).show();
                etMonthFilter.setText(selectedMonth + 1 + " - " + selectedYear);
                month = selectedMonth + 1;
                year = selectedYear;
            }
        }, today.get(Calendar.YEAR), today.get(Calendar.MONTH));

        builder.setActivatedMonth(Calendar.MARCH)
                .setMinYear(1990)
                .setActivatedYear(2020)
                .setMaxYear(2030)

                .setMinMonth(Calendar.JANUARY)
                .setTitle("Select trading month")
                .setMonthRange(Calendar.JANUARY, Calendar.DECEMBER)
                // .setMaxMonth(Calendar.OCTOBER)
                // .setYearRange(1890, 1890)
                // .setMonthAndYearRange(Calendar.FEBRUARY, Calendar.OCTOBER, 1890, 1890)
                //.showMonthOnly()
                // .showYearOnly()
                .setOnMonthChangedListener(new MonthPickerDialog.OnMonthChangedListener() {
                    @Override
                    public void onMonthChanged(int selectedMonth) {
                        Log.d("Arn", "Selected month : " + selectedMonth);
                        // Toast.makeText(MainActivity.this, " Selected month : " + selectedMonth, Toast.LENGTH_SHORT).show();
                    }
                })
                .setOnYearChangedListener(new MonthPickerDialog.OnYearChangedListener() {
                    @Override
                    public void onYearChanged(int selectedYear) {
                        Log.d("Arn", "Selected year : " + selectedYear);
                        // Toast.makeText(MainActivity.this, " Selected year : " + selectedYear, Toast.LENGTH_SHORT).show();
                    }
                })
                .build()
                .show();
    }

    public static String getDateStringFromMilliSeconds(Long s) {
        try {
            DateFormat simple = new SimpleDateFormat("dd-MM-yyyy");
            Date result = new Date(s);
            return simple.format(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void loadBookings(final String date) {
        if (loading != null)
            loading.show();
        bookings.clear();
        recyclerView.setAdapter(null);

        String url = "";
        if (month != 0 && year != 0) {
            url = "http://javatrainingkerala.com/restaurants/bookinglist_month.php";
        } else {
            url = "http://javatrainingkerala.com/restaurants/bookinglist.php";
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                        try {

                            Log.d("Arn", "response =" + response);

                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);
                            //traversing through all the object
                            for (int i = array.length() - 1; i >= 0; i--) {

                                JSONObject product = array.getJSONObject(i);
                                //adding the product to product list
                                bookings.add(new Booking(product.getString("id"),
                                        product.getString("user_id"),
                                        product.getString("name"),
                                        product.getString("restaurants_id"),
                                        product.getString("restaurant_name"),
                                        product.getString("date"),
                                        product.getString("time"),
                                        product.getString("amount")
                                        , product.getString("seat")

                                ));
                            }

                            bookingsAdapter = new BookingsAdapter(true, AdminBookingsActivity.this, bookings);
                            bookingsAdapter.notifyDataSetChanged();
                            recyclerView.setAdapter(bookingsAdapter);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (loading != null && loading.isShowing())
                            loading.dismiss();
                    }


                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request
                //returning parameter
                if (!date.equals(""))
                    params.put("date", date);
                else if (month != 0 && year != 0) {
                    params.put("month", month + "");
                    params.put("year", year + "");
                }
                Log.d("Arn", "params =" + params);
                return params;
            }

        };

        //Adding the string request to the queue
        RequestQueue requestQueue = Volley.newRequestQueue(AdminBookingsActivity.this);
        requestQueue.add(stringRequest);
    }

}
